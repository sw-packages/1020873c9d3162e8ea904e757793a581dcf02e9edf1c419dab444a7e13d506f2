#ifndef ZCHUNK_COMPRESSION_ZSTD_H
#define ZCHUNK_COMPRESSION_ZSTD_H

int zstd_setup(zckCtx *zck, zckComp *comp);

#endif
