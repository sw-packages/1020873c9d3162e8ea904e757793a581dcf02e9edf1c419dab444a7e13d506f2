#ifndef MEMMEM_H
#define MEMMEM_H
void *memmem(const void *haystack, size_t n, const void *needle, size_t m);
#endif
